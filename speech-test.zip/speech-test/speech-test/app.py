import streamlit as st
import speech_recognition as sr
import pyttsx3
import edge_tts
import tempfile
import os
import difflib
import re
import asyncio
import numpy as np
import matplotlib.pyplot as plt
import google.generativeai as genai

# 嘗試匯入 librosa
try:
    import librosa
    HAS_LIBROSA = True
except ImportError:
    HAS_LIBROSA = False

# ==========================================
# 0. UI 美化
# ==========================================
def inject_custom_css():
    st.markdown("""
        <style>
        .stApp { background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%); font-family: 'Helvetica Neue', sans-serif; }
        h1 { color: #2c3e50; text-align: center; font-weight: 800; }
        
        .css-card { 
            background-color: #ffffff; 
            border-radius: 15px; 
            padding: 25px; 
            box-shadow: 0 4px 15px rgba(0,0,0,0.05); 
            margin-bottom: 20px; 
            border: 1px solid #eee; 
        }
        
        .reading-box { 
            font-size: 28px !important; 
            font-weight: bold; 
            color: #2c3e50; 
            line-height: 1.6; 
            padding: 20px; 
            background-color: #f8f9fa; 
            border-left: 6px solid #2980b9; 
            border-radius: 8px; 
            margin-bottom: 20px;
        }

        /* 優化後的單字卡片 */
        .definition-box { 
            background-color: #fff8e1; /* 更柔和的黃色 */
            border: 2px solid #ffe082; 
            color: #5d4037; 
            padding: 20px; 
            border-radius: 12px; 
            margin-top: 15px; 
            font-size: 20px; /* 字體加大 */
            line-height: 1.8; /* 行距加大 */
            text-align: left; /* 改成靠左對齊，比較好讀 */
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            animation: fadeIn 0.5s;
        }
        
        /* 單字按鈕 */
        div.stButton > button {
            width: 100%;
            border-radius: 8px;
            border: 1px solid #dee2e6;
            background-color: white;
            color: #495057;
            font-size: 18px !important;
            transition: all 0.2s;
        }
        div.stButton > button:hover {
            border-color: #2980b9; color: #2980b9; background-color: #eaf2f8; transform: translateY(-2px);
        }

        .warning-bar { background-color: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; padding: 10px; border-radius: 5px; margin-bottom: 15px; }
        .ai-feedback-box { background-color: #e3f2fd; border-left: 5px solid #1565c0; padding: 15px; border-radius: 5px; color: #0d47a1; margin-top: 20px;}
        .diff-box { background-color: #fff; border: 2px dashed #bdc3c7; padding: 15px; border-radius: 10px; font-size: 18px; }
        
        @keyframes fadeIn { from { opacity: 0; transform: translateY(-10px); } to { opacity: 1; transform: translateY(0); } }
        </style>
    """, unsafe_allow_html=True)

# ==========================================
# 1. 核心工具函式
# ==========================================
def split_text_into_sentences(text):
    text = text.replace('\n', ' ')
    raw_sentences = re.split(r'(?<=[.!?])\s+', text)
    sentences = [s.strip() for s in raw_sentences if len(s.strip()) > 0]
    return sentences

def transcribe_audio(audio_path):
    r = sr.Recognizer()
    try:
        with sr.AudioFile(audio_path) as source:
            audio_data = r.record(source)
            text = r.recognize_google(audio_data, language="en-US")
            return text
    except: return ""

def check_similarity_visual(target, user_text):
    if not user_text: return 0, "無語音輸入"
    t_words = re.findall(r"\w+", target.lower())
    u_words = re.findall(r"\w+", user_text.lower())
    matcher = difflib.SequenceMatcher(None, t_words, u_words)
    score = matcher.ratio() * 100
    html_parts = []
    for tag, i1, i2, j1, j2 in matcher.get_opcodes():
        t_segment = " ".join(t_words[i1:i2])
        u_segment = " ".join(u_words[j1:j2])
        if tag == 'equal':
            html_parts.append(f'<span style="color:#27ae60; font-weight:bold;">{t_segment}</span>')
        elif tag == 'replace':
            html_parts.append(f'<span style="color:#c0392b; text-decoration:line-through;">{t_segment}</span>')
            html_parts.append(f'<span style="color:#7f8c8d; font-size:0.9em;">({u_segment})</span>')
        elif tag == 'delete':
            html_parts.append(f'<span style="background-color:#fadbd8; color:#c0392b;">{t_segment}</span>')
        elif tag == 'insert':
            html_parts.append(f'<span style="color:#7f8c8d; font-style:italic;">{u_segment}</span>')
    return score, " ".join(html_parts)

def plot_and_get_trend(teacher_path, student_path):
    if not HAS_LIBROSA: return None, 0, 0
    try:
        y_t, sr_t = librosa.load(teacher_path, sr=22050)
        f0_t, _, _ = librosa.pyin(y_t, fmin=50, fmax=400, frame_length=2048)
        y_s, sr_s = librosa.load(student_path, sr=22050)
        f0_s, _, _ = librosa.pyin(y_s, fmin=50, fmax=400, frame_length=2048)
        if f0_t is None or f0_s is None: return None, 0, 0
        def normalize(f0):
            valid = f0[~np.isnan(f0)]
            if len(valid) == 0: return np.array([])
            return (valid - np.mean(valid)) / (np.std(valid) + 1e-6)
        norm_t = normalize(f0_t)
        norm_s = normalize(f0_s)
        if len(norm_t) == 0 or len(norm_s) == 0: return None, 0, 0
        from scipy.signal import resample
        norm_s_res = resample(norm_s, len(norm_t))
        fig, ax = plt.subplots(figsize=(8, 2.5))
        fig.patch.set_alpha(0); ax.patch.set_alpha(0)
        ax.plot(norm_t, label='Teacher', color='#2980b9', linewidth=3)
        ax.plot(norm_s_res, label='You', color='#e67e22', linestyle='--', linewidth=3)
        ax.legend(); ax.axis('off')
        plt.close(fig)
        score = max(0, np.corrcoef(norm_t, norm_s_res)[0, 1]) * 100
        seg = norm_s_res[int(len(norm_s_res)*0.7):]
        trend = 0
        if len(seg) > 1:
            diff = np.mean(seg[len(seg)//2:]) - np.mean(seg[:len(seg)//2])
            trend = 1 if diff > 0.2 else -1 if diff < -0.2 else 0
        return fig, score, trend
    except: return None, 0, 0

def get_ai_coach_feedback(api_key, target_text, user_text, pitch_trend, score):
    if not api_key: return "⚠️ 請在側邊欄輸入 Google API Key"
    try:
        genai.configure(api_key=api_key)
        model = genai.GenerativeModel('gemini-pro')
        trend_str = "上揚 ↗" if pitch_trend == 1 else "下降 ↘" if pitch_trend == -1 else "平淡 →"
        prompt = f"""
        你是一位幽默的英文發音教練。
        目標句子："{target_text}" / 學生唸："{user_text}" / 語調：{trend_str} / 分數：{score:.0f}
        請包含：1.發音糾正 2.語調建議 3.一句鼓勵。
        """
        response = model.generate_content(prompt)
        return response.text
    except Exception as e: return f"AI 連線錯誤：{str(e)}"

# === 關鍵修改：讓單字查詢結果分行顯示 ===
@st.cache_data(show_spinner=False)
def get_word_info(api_key, word, sentence):
    if not api_key: return "⚠️ 請先輸入 API Key"
    try:
        genai.configure(api_key=api_key)
        model = genai.GenerativeModel('gemini-pro')
        # 加上提示詞，要求AI分行回傳
        prompt = f"""
        請解釋單字 "{word}" 在句子 "{sentence}" 中的意思。
        請嚴格依照以下格式回傳 (每項換一行)：
        
        🔊 [{word}] KK音標
        🏷️ [詞性]
        💡 [繁體中文意思]
        
        請直接給出內容，不要多餘的開場白。
        """
        response = model.generate_content(prompt)
        return response.text
    except Exception as e:
        return f"❌ 查詢失敗：\n{str(e)}"

# 發音引擎
async def _edge_tts_generate(text, voice, rate_str, output_file):
    communicate = edge_tts.Communicate(text, voice, rate=rate_str)
    await communicate.save(output_file)

def speak_online(text, voice_id, speed):
    try:
        rate_val = int((speed - 1.0) * 100)
        rate_str = f"+{rate_val}%" if rate_val >= 0 else f"{rate_val}%"
        with tempfile.NamedTemporaryFile(delete=False, suffix=".mp3") as fp: path = fp.name
        loop = asyncio.new_event_loop(); asyncio.set_event_loop(loop)
        loop.run_until_complete(_edge_tts_generate(text, voice_id, rate_str, path)); loop.close()
        return path, voice_id
    except: return None, None

def speak_offline_specific(text, voice_id, speed):
    try:
        engine = pyttsx3.init()
        engine.setProperty('rate', int(175 * speed))
        engine.setProperty('voice', voice_id)
        with tempfile.NamedTemporaryFile(delete=False, suffix=".wav") as fp: path = fp.name
        engine.save_to_file(text, path); engine.runAndWait()
        return path, voice_id
    except: return None, None

def get_offline_voices():
    try:
        engine = pyttsx3.init()
        voices = engine.getProperty('voices')
        return {v.name: v.id for v in voices}
    except: return {}

# ==========================================
# 2. 主程式
# ==========================================

st.set_page_config(page_title="AI 英文教練 Pro", layout="wide", page_icon="🎤")
inject_custom_css()

if 'game_active' not in st.session_state: st.session_state.game_active = False
if 'sentences' not in st.session_state: st.session_state.sentences = []
if 'current_index' not in st.session_state: st.session_state.current_index = 0
if 'current_audio_path' not in st.session_state: st.session_state.current_audio_path = None
if 'last_online_fail' not in st.session_state: st.session_state.last_online_fail = False
if 'current_word_definition' not in st.session_state: st.session_state.current_word_definition = None

KEY_FILE = "secret_key.txt"
if 'saved_api_key' not in st.session_state:
    if os.path.exists(KEY_FILE):
        with open(KEY_FILE, "r") as f: st.session_state.saved_api_key = f.read().strip()
    else: st.session_state.saved_api_key = ""

with st.sidebar:
    st.title("⚙️ 設定")
    gemini_api_key = st.text_input("🔑 Google API Key", value=st.session_state.saved_api_key, type="password")
    if gemini_api_key != st.session_state.saved_api_key:
        with open(KEY_FILE, "w") as f: f.write(gemini_api_key)
        st.session_state.saved_api_key = gemini_api_key
    
    st.markdown("---")
    tts_mode = st.radio("模式", ["☁️ 線上 (AI)", "💻 離線 (Windows)"], index=0)
    selected_voice_id = None
    if "線上" in tts_mode:
        online_voices = {"🇺🇸 Jenny": "en-US-JennyNeural", "🇺🇸 Christopher": "en-US-ChristopherNeural", "🇬🇧 Sonia": "en-GB-SoniaNeural"}
        voice_choice = st.selectbox("AI 角色", list(online_voices.keys()))
        selected_voice_id = online_voices[voice_choice]
    else:
        offline_voices = get_offline_voices()
        if not offline_voices: st.error("無離線語音")
        else:
            voice_choice = st.selectbox("內建語音", list(offline_voices.keys()))
            selected_voice_id = offline_voices[voice_choice]
    voice_speed = st.slider("語速", 0.5, 1.5, 1.0, 0.1)

st.title("🎤 Voice Lab 英文跟讀教練")

if st.session_state.last_online_fail:
    st.markdown('<div class="warning-bar">🚨 連線失敗，已自動切換為離線發音。</div>', unsafe_allow_html=True)
    st.session_state.last_online_fail = False

# 輸入區
if not st.session_state.game_active:
    st.markdown('<div class="css-card">', unsafe_allow_html=True)
    input_text = st.text_area("📝 請貼上文章：", value="When you travel, always plan ahead so you know where you are going.", height=150)
    if st.button("🚀 開始練習", type="primary"):
        s = split_text_into_sentences(input_text)
        if s: st.session_state.sentences = s; st.session_state.current_index = 0; st.session_state.game_active = True; st.rerun()
    st.markdown('</div>', unsafe_allow_html=True)

# 練習區
else:
    idx = st.session_state.current_index; sentences = st.session_state.sentences; target_sentence = sentences[idx]
    if idx >= len(sentences):
        st.balloons(); st.success("🏆 完成！"); st.stop()

    st.progress((idx+1)/len(sentences), text=f"句數 {idx+1}/{len(sentences)}")

    st.markdown('<div class="css-card">', unsafe_allow_html=True)
    c1, c2 = st.columns([1.5, 1], gap="large")

    with c1:
        st.markdown("### 📖 閱讀與查詢")
        
        # 1. 顯示完整句子
        st.markdown(f'<div class="reading-box">{target_sentence}</div>', unsafe_allow_html=True)
        
        # 2. 單字查詢區
        st.caption("👇 點擊下方單字查詢意思：")
        words = re.findall(r"\b\w+\b", target_sentence) 
        
        cols = st.columns(5)
        for i, word in enumerate(words):
            if cols[i % 5].button(word, key=f"btn_{i}_{idx}"):
                if gemini_api_key:
                    with st.spinner("🔍..."):
                        # 呼叫查詢函式
                        info = get_word_info(gemini_api_key, word, target_sentence)
                        st.session_state.current_word_definition = info
                else:
                    st.error("請在左側輸入 Google API Key")

        # === 顯示結果 (美化排版) ===
        if st.session_state.current_word_definition:
            # 將 \n 轉換為 HTML 的 <br> 以確保網頁上能換行
            formatted_info = st.session_state.current_word_definition.replace("\n", "<br>")
            st.markdown(f'<div class="definition-box">{formatted_info}</div>', unsafe_allow_html=True)

        st.write("")
        path = None; engine_name = "離線"
        if "線上" in tts_mode and selected_voice_id:
            path, vid = speak_online(target_sentence, selected_voice_id, voice_speed)
            if path: engine_name = "線上AI"
            else:
                st.session_state.last_online_fail = True
                off_v = get_offline_voices()
                if off_v: path, vid = speak_offline_specific(target_sentence, list(off_v.values())[0], voice_speed); engine_name="離線備援"
        elif selected_voice_id:
            path, vid = speak_offline_specific(target_sentence, selected_voice_id, voice_speed)
        
        st.caption(f"🔈 播放引擎: {engine_name}")
        if path: st.audio(path)

    with c2:
        st.markdown("### 🎙️ 口說挑戰")
        user_audio = st.audio_input("錄音", key=f"rec_{idx}")
    st.markdown('</div>', unsafe_allow_html=True)

    if user_audio and path:
        with st.spinner("📊 分析中..."):
            with tempfile.NamedTemporaryFile(delete=False, suffix=".wav") as tmp: tmp.write(user_audio.read()); user_path = tmp.name
            u_text = transcribe_audio(user_path)
            score, diff_html = check_similarity_visual(target_sentence, u_text)
            fig, p_score, trend = plot_and_get_trend(path, user_path)
            final = score
            if HAS_LIBROSA and fig: final = (score * 0.7) + (p_score * 0.3)
            feedback = get_ai_coach_feedback(gemini_api_key, target_sentence, u_text, trend, final)

        if final >= 80: st.success(f"🎉 過關！分數：{final:.0f}")
        else: st.error(f"❌ 未達標，分數：{final:.0f}")

        st.markdown(f"<div class='ai-feedback-box'><strong>🤖 AI 講評：</strong><br>{feedback}</div>", unsafe_allow_html=True)
        t1, t2 = st.tabs(["🔤 糾錯", "📈 語調"])
        with t1: st.markdown(f"<div class='diff-box'>{diff_html}</div>", unsafe_allow_html=True)
        with t2: 
            if fig: st.pyplot(fig) 
            else: st.warning("無法分析語調")

        if final >= 80:
            st.markdown("---")
            if st.button("➡️ 下一句", type="primary"):
                st.session_state.current_index += 1; st.session_state.current_audio_path = None; st.session_state.current_word_definition = None; st.rerun()